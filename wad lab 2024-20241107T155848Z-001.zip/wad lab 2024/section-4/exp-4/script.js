// Write javascript code to check whether the number input given by the user is negative.
var num=prompt("enter a number");
if(num<0){
    alert("number is negative")
}

// Write javascript code to check whether the number input given by the user is negative.
if(num<0){
    alert("number is negative");
}
else{
    alert("number is non negative");
}

// check whether the number input given by the user is negative or positive or zero.

if(num<0){
    alert("numberis negative");
}
else if(num>0){
    alert("nuber is positive");
}
else{
    alert("number is zero");
}


// get a day number input from the user and print the corresponding day of the week.

var day=parseInt(prompt("enter a day number"));
switch(day){
    case 1:consoleconsole.log("sunday");
            break;
    case 2:console.log("Monday");
            break;
    case 3:console.log("Tuesday");
            break;
    case 4:console.log("Wednesday");
            break;
    case 5:console.log("Thursday");
            break;
    case 6:console.log("Friday");
            break;
    case 7:console.log("Saturday");
            break;
    default:console.log("incorrect day number");
            break;
}
