var length=parseInt(prompt("enter the length"));
var breadth=parseInt(prompt("enter the breadth"));
var area=length*breadth;
console.log("area = "+area);
alert("area ="+area);
