var round=0;
var p1=0;
var p2=0;
var roundtxt=document.querySelector("h4");
var winnertxt=document.querySelector("h2");

var p1txt=document.querySelector("#p1")
var p2txt=document.querySelector("#p2")

var diceimg1=document.querySelector("#dice1");
var diceimg2=document.querySelector("#dice2");
var btn=document.getElementById("sub-btn");

btn.addEventListener("click",function(e){
    e.preventDefault();
    var random1=Math.ceil(Math.random()*6);
    var random2=Math.ceil(Math.random()*6);

    round++;
    roundtxt.textContent=`ROUND :${round}`;

    diceimg1.setAttribute("src",`images/${random1}.jpg`);
    
    diceimg2.setAttribute("src",`images/${random2}.jpg`);
    
    if(random1>random2){
        p1++;
        winnertxt.textContent=`Player 1 Wins`;
        p1txt.textContent=`P1 :${p1} `
    }
    else if(random2>random1){
        p2++;
        winnertxt.textContent=`Player 2 Wins`;
        p2txt.textContent=`P1 :${p2} `
    }
    else if(random2=random1){
        winnertxt.textContent=`DRAW`;
    }
});