let bulb=document.querySelector("img");
let btn=document.querySelector("input[type='button']");
count=0;
btn.addEventListener("click",function(e){
    if(count==0){
        bulb.setAttribute("src","light-on.png");
        btn.setAttribute("value","light-on")
        count=1;
    }
    else if(count==1){
        bulb.setAttribute("src","light-off.png");
        btn.setAttribute("value","light-off")
        count=0;
    }

})