var name=prompt("enter your name");
alert("welcome "+name);
console.log("welcome "+name)
