var limit=parseInt(prompt("enter the limit"));
for(var i=0;i<limit;i++){
    console.log(i);
}

var j=0;
while(j<limit){
    console.log(j);
    j++;
}

do{
    var limit=parseInt(prompt("enter the limit"));
    var k=0;
    while(k<limit){
        console.log(k);
        k++;
    }
    var c= prompt("Do you want to enter a new limit? (Y/N): ")
}while(c=="Y")
