// Array to hold books
let books = [];

// Function to add a book
function addBook() {
    const title = document.getElementById("bookTitle").value;
    const author = document.getElementById("bookAuthor").value;

    if (title && author) {
        books.push({ title, author });
        displayBooks();
        alert("Book added successfully!");
        document.getElementById("addBookForm").reset();
    }
}

// Function to remove a book by title
function removeBook(bookTitle) {
    // Find the book and remove it from the array
    books = books.filter(book => book.title !== bookTitle);
    displayBooks();
}

// Function to display books in the book list
function displayBooks() {
    const bookList = document.getElementById("bookList");
    bookList.innerHTML = ''; // Clear previous list

    if (books.length === 0) {
        const noBooks = document.createElement("p");
        noBooks.textContent = "No books available in the collection.";
        bookList.appendChild(noBooks);
    } else {
        books.forEach(book => {
            const li = document.createElement("li");
            li.textContent = `Title: ${book.title}, Author: ${book.author} `;

            // Create a remove button for each book
            const removeButton = document.createElement("button");
            removeButton.textContent = "Remove";
            removeButton.onclick = function() {
                removeBook(book.title);  // Remove the specific book
            };

            li.appendChild(removeButton);
            bookList.appendChild(li);
        });
    }
}

// Initial call to displayBooks to show message if no books are added
displayBooks();
